#include "lines.h"

lines::lines()
{


}

/*lines::lines(QPoint _start, QPoint _end, QColor _color, int _th)
{
    start = _start;
    end = _end;
    color = _color;
    thickness = _th;

}*/
