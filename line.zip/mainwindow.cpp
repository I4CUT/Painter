#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QMouseEvent>
#include <QPainter>
#include <QColorDialog>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    form = new Form();
     connect(form, &Form::signal, this, &MainWindow::set_thickness);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::mousePressEvent(QMouseEvent *event)
{
    if(event == nullptr) return;
             start_point = event->pos();
current.start = start_point;
}

void MainWindow::mouseReleaseEvent(QMouseEvent *event)
{
     if(event == nullptr) return;
     lines.push_back(current);
     update();
}

void MainWindow::mouseMoveEvent(QMouseEvent *event)
{
    if(event == nullptr) return;


        end_point = event->pos();
        current.end = end_point;


     update();
}

void MainWindow::paintEvent(QPaintEvent *event)
{
    QPainter painter(this);


    painter.drawLine(current.start, current.end);
    for (const auto& el : lines) {

         painter.setPen(QPen(QBrush(QColor(el.color)),el.thickness));

            painter.drawLine(el.start, el.end);
        }
    QMainWindow::paintEvent(event);


}

void MainWindow::set_thickness(QString string)
{
    current.thickness = string.toInt();
    qDebug() << thickness;
}



void MainWindow::on_colorButton_clicked()
{
    current.color = QColorDialog::getColor(Qt::white, this);
}

void MainWindow::on_pushButton_clicked()
{
    form->show();
}
