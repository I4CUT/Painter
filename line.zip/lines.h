#ifndef LINES_H
#define LINES_H
#include <QColor>
#include <QPoint>

class lines
{
public:
    QPoint start;
    QPoint end;
    QColor color = "black";
    int thickness = 1;
public:
    lines();
    lines(QPoint _start, QPoint _end, QColor _color, int _th);
};

#endif // LINES_H
